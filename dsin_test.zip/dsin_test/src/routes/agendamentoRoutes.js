const express = require('express');
const Agendamento = require('../models/Agendamento');

const router = express.Router();

// Criar agendamento
router.post('/', async (req, res) => {
    try {
        const { nomeCliente, servicos, data } = req.body;
        const novoAgendamento = new Agendamento({ nomeCliente, servicos, data });
        await novoAgendamento.save();

        res.status(201).json({
        mensagem: 'Agendamento criado com sucesso!',
        agendamento: novoAgendamento,
        });
    } catch (error) {
        res.status(500).json({ mensagem: 'Erro ao criar agendamento', erro: error });
    }
});

// Atualizar agendamento
router.put('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const { nomeCliente, servicos, data } = req.body;

        const hoje = new Date();
        console.log(`Data de hoje: ${hoje.toISOString()}`);

        // Buscar agendamento pelo ID
        const agendamento = await Agendamento.findById(id);

        if (!agendamento) {
            return res.status(404).json({ mensagem: 'Agendamento não encontrado' });
        }

        // Data original do agendamento no banco
        const dataAgendada = new Date(agendamento.data);
        console.log(`Data original do agendamento: ${dataAgendada.toISOString()}`);

        // Data fornecida na requisição
        const novaData = new Date(data);
        console.log(`Data fornecida na requisição: ${novaData.toISOString()}`);

        // Calcular a diferença em dias entre a nova data e a data original
        const diferencaDias = (dataAgendada - novaData) / (1000 * 60 * 60 * 24); // Diferença em dias

        console.log(`Diferença em dias entre a nova data e a data agendada: ${diferencaDias}`);

        // Validando se a alteração é permitida (a alteração pode ser feita até 2 dias antes da data agendada)
        if (diferencaDias > 2) {
            return res.status(400).json({
                mensagem: 'Alterações só podem ser feitas até 2 dias antes da data agendada. Por favor, entre em contato por telefone.',
            });
        }

        // Atualizando os dados fornecidos
        agendamento.nomeCliente = nomeCliente || agendamento.nomeCliente;
        agendamento.servicos = servicos || agendamento.servicos;
        agendamento.data = data || agendamento.data;

        // Salvando as alterações no banco
        await agendamento.save();

        res.status(200).json({
            mensagem: 'Agendamento atualizado com sucesso!',
            agendamento,
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({
            mensagem: 'Erro ao atualizar agendamento',
            erro: error.message || error,
        });
    }
});




// Listar todos os agendamentos
router.get('/', async (req, res) => {
    try {
        const agendamentos = await Agendamento.find(); // Busca todos os agendamentos
        res.status(200).json(agendamentos); // Retorna os agendamentos encontrados
    } catch (error) {
        res.status(500).json({ mensagem: 'Erro ao buscar agendamentos', erro: error });
    }
});

// Listar agendamento por ID
router.get('/:id', async (req, res) => {
    try {
        const { id } = req.params;

        const agendamento = await Agendamento.findById(id);

        if (!agendamento) {
        return res.status(404).json({ mensagem: 'Agendamento não encontrado' });
        }

        res.status(200).json(agendamento);
    } catch (error) {
        res.status(500).json({ mensagem: 'Erro ao buscar agendamento', erro: error });
    }
});

// Excluir agendamento
router.delete('/:id', async (req, res) => {
    try {
    const { id } = req.params;

    // Log para verificar se o ID está correto
    console.log(`Tentando excluir agendamento com ID: ${id}`);

    const agendamento = await Agendamento.findById(id);

    // Verifica se o agendamento foi encontrado
    if (!agendamento) {
        console.log('Agendamento não encontrado');
        return res.status(404).json({ mensagem: 'Agendamento não encontrado' });
        }

        const resultado = await Agendamento.deleteOne({ _id: id });

        if (resultado.deletedCount === 0) {
        console.log('Erro ao tentar excluir o agendamento');
        return res.status(500).json({ mensagem: 'Falha ao excluir agendamento' });
        }

        res.status(200).json({ mensagem: 'Agendamento excluído com sucesso!' });
    } catch (error) {
        console.error('Erro ao excluir agendamento:', error);
        res.status(500).json({
        mensagem: 'Erro ao excluir agendamento',
        erro: error.message || error,
        });
    }
});

module.exports = router;
