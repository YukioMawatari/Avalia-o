const express = require('express');
const Agendamento = require('../models/Agendamento');

const router = express.Router();

router.get('/', async (req, res) => {
    try {
    const inicioSemana = new Date();
    inicioSemana.setDate(inicioSemana.getDate() - inicioSemana.getDay());

    const fimSemana = new Date(inicioSemana);
    fimSemana.setDate(fimSemana.getDate() + 6);

    const agendamentosSemana = await Agendamento.find({
        data: { $gte: inicioSemana, $lte: fimSemana },
    });

    const totalAgendamentos = agendamentosSemana.length;
    const servicosMaisSolicitados = agendamentosSemana.reduce((acumulador, agendamento) => {
        agendamento.servicos.forEach((servico) => {
            acumulador[servico] = (acumulador[servico] || 0) + 1;
        });
        return acumulador;
        }, {});

        res.status(200).json({
        totalAgendamentos,
        servicosMaisSolicitados,
        });
    } catch (error) {
        res.status(500).json({ mensagem: 'Erro ao gerar o painel de desempenho', erro: error });
    }
});

module.exports = router;
