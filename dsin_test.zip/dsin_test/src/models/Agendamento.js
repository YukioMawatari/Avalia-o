const mongoose = require('mongoose');

const AgendamentoSchema = new mongoose.Schema({
    nomeCliente: { type: String, required: true },
    servicos: [{ type: String, required: true }],
    data: { type: Date, required: true },
    status: { type: String, default: 'pendente' },
});

module.exports = mongoose.model('Agendamento', AgendamentoSchema);
