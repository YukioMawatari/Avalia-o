const express = require('express');
const conectarBancoDados = require('./config/database');
const agendamentoRoutes = require('./routes/agendamentoRoutes');
const dashboardRoutes = require('./routes/dashboardRoutes');
require('dotenv').config();

const app = express();
app.use(express.json());

// Conectar ao banco de dados
conectarBancoDados();

// Configurar rotas
app.use('/agendamentos', agendamentoRoutes);
app.use('/dashboard', dashboardRoutes);

// Iniciar o servidor
const PORTA = process.env.PORT || 3000;
app.listen(PORTA, () => console.log(`Servidor rodando na porta ${PORTA}`));
